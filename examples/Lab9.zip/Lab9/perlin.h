/*********************************************
 *
 *           Perlin.h
 *
 *  Declarations of functions in the perlin
 *  noise library.
 *
 *******************************************/

double noise1(double arg);
float noise2(float vec[2]);
float noise3(float vec[3]);

